from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes
from datetime import time
import sqlite3
import os

TOKEN = os.getenv("TOKEN")


DB_NAME = "users.db"



# DATABASE


def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY
        )
    """)

    conn.commit()
    conn.close()


def save_user(user_id: int):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute(
        "INSERT OR IGNORE INTO users (user_id) VALUES (?)",
        (user_id,)
    )

    conn.commit()
    conn.close()


def load_users():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("SELECT user_id FROM users")

    users = [row[0] for row in c.fetchall()]

    conn.close()

    return users


# -------------------------
# START
# -------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    user_id = update.effective_user.id
    save_user(user_id)

    keyboard = [
        [InlineKeyboardButton("⛽️ VISUALIZZA MENÙ ✈️", url="https://hashbmb.up.railway.app/")],
        [InlineKeyboardButton("✅ VERIFICATI ✅", url="https://t.me/H4SHBOMB")],
        [InlineKeyboardButton("🍁🚀 ACQUISTA 🍁🚀", url="https://t.me/H4SHBOMB")],
        [InlineKeyboardButton("👥 GRUPPO 🍁", url="https://t.me/+Pk5QXL8GNDpjNThk")],
        [InlineKeyboardButton("🔥 RECENSIONI 😉", url="https://t.me/+kMGEzX7AEApjYTI0")]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)

    welcome_text = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✅🤝🏽 PRIMA DI ACQUISTARE BISOGNA VERIFICARSI 🤝🏽✅\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "🔥😉 BENVENUTO NELLA VETRINA DI H4SH BOMB 😉🔥\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "👀 Qui troverete prodotti curati\n"
        "e selezionati personalmente 🔥\n\n"
        "💎 Qualità • Affidabilità • Selezione\n\n"
        "👇 PREMI UNO DEI PULSANTI 👇\n"
        "VISUALIZZATI QUI SOTTO\n\n"
        "🔥⬇️🔥⬇️🔥⬇️🔥⬇️🔥"
    )

    try:
        with open("photo_2026-06-06_19-18-18.jpg", "rb") as photo:
            await update.message.reply_photo(
                photo=photo,
                caption=welcome_text,
                reply_markup=reply_markup
            )

    except FileNotFoundError:
        await update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup
        )

# MESSAGGIO GIORNALIERO


async def daily_message(context: ContextTypes.DEFAULT_TYPE):

    users = load_users()

    for user_id in users:
        try:
            with open("photo_2026-06-06_19-18-18.jpg", "rb") as photo:
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=photo,
                    caption=(
                        "🔔 REMINDER ⚠️\n\n"
                        "📱ATTIVI PER NUOVI ORDINI📱"
                    )
                )

        except Exception as e:
            print(f"Errore invio a {user_id}: {e}")




# -------------------------
# MAIN
# -------------------------

def main():

    init_db()

    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))

    if app.job_queue:
        app.job_queue.run_daily(
            daily_message,
            time=time(hour=14, minute=0)
        )
    else:
        print("JobQueue non disponibile")

    print("Bot avviato...")

    app.run_polling()


if __name__ == "__main__":
    main()
